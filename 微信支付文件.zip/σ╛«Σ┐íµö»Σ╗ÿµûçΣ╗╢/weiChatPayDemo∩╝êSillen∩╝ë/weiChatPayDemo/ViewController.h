//
//  ViewController.h
//  weiChatPayDemo
//
//  Created by liweidong on 16/9/1.
//  Copyright © 2016年 Li Wei Dong. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController


@end

