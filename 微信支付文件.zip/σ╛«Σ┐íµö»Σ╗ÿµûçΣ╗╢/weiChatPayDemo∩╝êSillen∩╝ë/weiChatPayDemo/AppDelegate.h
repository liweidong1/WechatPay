//
//  AppDelegate.h
//  weiChatPayDemo
//
//  Created by liweidong on 16/9/1.
//  Copyright © 2016年 Li Wei Dong. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

