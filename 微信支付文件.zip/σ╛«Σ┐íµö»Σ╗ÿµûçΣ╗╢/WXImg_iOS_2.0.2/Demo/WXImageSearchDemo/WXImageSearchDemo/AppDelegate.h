//
//  AppDelegate.h
//  WXImageSearchDemo
//
//  Created by 宫亚东 on 13-12-30.
//  Copyright (c) 2013年 Tencent Research. All rights reserved.
//

#import <UIKit/UIKit.h>
@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end
