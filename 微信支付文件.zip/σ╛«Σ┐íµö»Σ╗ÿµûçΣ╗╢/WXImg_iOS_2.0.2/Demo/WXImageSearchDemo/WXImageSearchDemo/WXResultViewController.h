//
//  WXResultViewController.h
//  WXImageSearchDemo
//
//  Created by 宫亚东 on 13-12-31.
//  Copyright (c) 2013年 Tencent Research. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface WXResultViewController : UIViewController

- (void)sendImage:(UIImage *)image;

@end
