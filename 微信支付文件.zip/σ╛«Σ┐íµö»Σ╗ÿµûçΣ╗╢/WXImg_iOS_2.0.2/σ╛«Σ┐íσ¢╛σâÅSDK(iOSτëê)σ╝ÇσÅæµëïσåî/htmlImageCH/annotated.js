var annotated =
[
    [ "WXImageSearch", "interface_w_x_image_search.html", "interface_w_x_image_search" ],
    [ "<WXImageSearchDelegate>", "protocol_w_x_image_search_delegate-p.html", "protocol_w_x_image_search_delegate-p" ],
    [ "WXImageSearchResult", "interface_w_x_image_search_result.html", "interface_w_x_image_search_result" ]
];