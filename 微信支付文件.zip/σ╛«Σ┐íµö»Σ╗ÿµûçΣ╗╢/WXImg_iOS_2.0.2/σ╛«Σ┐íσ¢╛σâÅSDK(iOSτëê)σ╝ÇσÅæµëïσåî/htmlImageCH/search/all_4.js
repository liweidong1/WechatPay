var searchData=
[
  ['picdesc',['picDesc',['../interface_w_x_image_search_result.html#a917dfeaaa2685718f622268d231a1ce7',1,'WXImageSearchResult']]]
];
