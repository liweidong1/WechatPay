var searchData=
[
  ['cancel',['cancel',['../interface_w_x_image_search.html#a551c74c023717a3def2362057befc821',1,'WXImageSearch']]]
];
