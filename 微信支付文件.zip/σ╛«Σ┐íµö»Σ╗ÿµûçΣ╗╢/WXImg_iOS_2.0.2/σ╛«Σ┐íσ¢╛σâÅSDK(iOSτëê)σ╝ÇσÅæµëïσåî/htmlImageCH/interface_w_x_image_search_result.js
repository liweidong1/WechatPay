var interface_w_x_image_search_result =
[
    [ "md5", "interface_w_x_image_search_result.html#a56638b36b3f6bf0f7f2f3d799afe9a0e", null ],
    [ "picDesc", "interface_w_x_image_search_result.html#a917dfeaaa2685718f622268d231a1ce7", null ],
    [ "url", "interface_w_x_image_search_result.html#a977ec05fb7fbe3e323023c5d583141f9", null ]
];