var interface_w_x_image_search =
[
    [ "cancel", "interface_w_x_image_search.html#a551c74c023717a3def2362057befc821", null ],
    [ "releaseImageSearch", "interface_w_x_image_search.html#a88e6b2889342e3343b850986230cc141", null ],
    [ "setAppID:", "interface_w_x_image_search.html#a3bc5391c696d45083b37740b3a9320f0", null ],
    [ "sharedImageSearch", "interface_w_x_image_search.html#aac53379f50a5d7d78649495274822a8b", null ],
    [ "startWithImage:", "interface_w_x_image_search.html#a64cce16aeb3995056b751d3eb65fe3ca", null ],
    [ "startWithJPGImageData:", "interface_w_x_image_search.html#a46b66d5da3ed7d625166677b6153e5b0", null ],
    [ "delegate", "interface_w_x_image_search.html#a8b568a9c1ce69fabe6886a7c4c318f1b", null ]
];