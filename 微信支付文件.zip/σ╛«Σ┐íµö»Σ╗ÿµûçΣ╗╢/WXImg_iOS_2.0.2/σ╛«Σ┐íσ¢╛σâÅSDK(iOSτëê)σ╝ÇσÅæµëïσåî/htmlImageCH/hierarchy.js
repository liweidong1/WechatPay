var hierarchy =
[
    [ "NSObject", null, [
      [ "WXImageSearch", "interface_w_x_image_search.html", null ],
      [ "WXImageSearchResult", "interface_w_x_image_search_result.html", null ]
    ] ],
    [ "<NSObjectNSObject>", null, [
      [ "<WXImageSearchDelegate>", "protocol_w_x_image_search_delegate-p.html", null ]
    ] ]
];