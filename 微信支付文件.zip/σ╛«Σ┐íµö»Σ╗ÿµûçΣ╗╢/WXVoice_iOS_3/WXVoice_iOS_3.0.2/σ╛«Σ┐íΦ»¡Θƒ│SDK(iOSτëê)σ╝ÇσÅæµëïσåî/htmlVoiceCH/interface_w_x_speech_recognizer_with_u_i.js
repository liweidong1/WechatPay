var interface_w_x_speech_recognizer_with_u_i =
[
    [ "initWithDelegate:andAppID:", "interface_w_x_speech_recognizer_with_u_i.html#a185e4c92d12dcd04733723e1db686c5a", null ],
    [ "orientationChanged", "interface_w_x_speech_recognizer_with_u_i.html#ae0c52f4c21edab3c551448b859788b9f", null ],
    [ "setDomain:", "interface_w_x_speech_recognizer_with_u_i.html#a046f64320fd6d6b70d1d74e164b57a75", null ],
    [ "setResultType:", "interface_w_x_speech_recognizer_with_u_i.html#a9ce6f38f1c66cfbd2e0f6b202fb690c1", null ],
    [ "setSilTime:", "interface_w_x_speech_recognizer_with_u_i.html#a3e146fef69389558a7a067604dd8114f", null ],
    [ "showAndStart", "interface_w_x_speech_recognizer_with_u_i.html#a3f2c4a13d7ee552f7a7a62ec9a4fbc7b", null ],
    [ "showAndStartOnceWithGrammarString:andType:", "interface_w_x_speech_recognizer_with_u_i.html#a079e533fc80aa2166778cb418829ae8a", null ]
];