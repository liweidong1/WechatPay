var interface_w_x_speech_synthesizer =
[
    [ "cancel", "interface_w_x_speech_synthesizer.html#a800f97fc7aa57300099914bf37c66bdf", null ],
    [ "releaseSpeechSynthesizer", "interface_w_x_speech_synthesizer.html#a9c9c621153bd7311061a7f014f3c8354", null ],
    [ "setAppID:", "interface_w_x_speech_synthesizer.html#aa991b71142243b1367827be24c9431cf", null ],
    [ "setSpeechFormat:", "interface_w_x_speech_synthesizer.html#aab8a13bf0a688f860e5658ea1af55309", null ],
    [ "setVolumn:", "interface_w_x_speech_synthesizer.html#ac7221257aaa6f28af48a7b4d891ce5bc", null ],
    [ "sharedSpeechSynthesizer", "interface_w_x_speech_synthesizer.html#a95015e0ddb9648ed56592ba21ca2aa62", null ],
    [ "startWithText:", "interface_w_x_speech_synthesizer.html#a4c19b43a9f03d62948a4a37d9722ecbe", null ],
    [ "delegate", "interface_w_x_speech_synthesizer.html#a93db869a6d6fd6926e5fe3559537a07f", null ]
];