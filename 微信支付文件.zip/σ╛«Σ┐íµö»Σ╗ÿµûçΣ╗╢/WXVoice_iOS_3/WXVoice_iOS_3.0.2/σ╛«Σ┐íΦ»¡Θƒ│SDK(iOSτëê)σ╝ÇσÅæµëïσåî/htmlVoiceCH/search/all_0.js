var searchData=
[
  ['cancel',['cancel',['../interface_w_x_speech_synthesizer.html#a800f97fc7aa57300099914bf37c66bdf',1,'WXSpeechSynthesizer::cancel()'],['../interface_w_x_voice_s_d_k.html#a82695ca22dfac022d7d4ba683774e8ec',1,'WXVoiceSDK::cancel()']]]
];
