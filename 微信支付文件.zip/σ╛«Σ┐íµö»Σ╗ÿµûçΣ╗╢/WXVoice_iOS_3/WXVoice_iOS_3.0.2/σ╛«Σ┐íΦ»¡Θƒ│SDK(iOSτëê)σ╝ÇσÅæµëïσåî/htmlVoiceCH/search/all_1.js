var searchData=
[
  ['delegate',['delegate',['../interface_w_x_speech_synthesizer.html#a93db869a6d6fd6926e5fe3559537a07f',1,'WXSpeechSynthesizer::delegate()'],['../interface_w_x_voice_s_d_k.html#ac2976de99de360db40487412e179b492',1,'WXVoiceSDK::delegate()']]],
  ['domain',['domain',['../interface_w_x_voice_s_d_k.html#ab7ad7ea678b7015b5c589fe0e0fc7f9e',1,'WXVoiceSDK']]]
];
