var searchData=
[
  ['wxspeechrecognizerwithui',['WXSpeechRecognizerWithUI',['../interface_w_x_speech_recognizer_with_u_i.html',1,'']]],
  ['wxspeechsynthesizer',['WXSpeechSynthesizer',['../interface_w_x_speech_synthesizer.html',1,'']]],
  ['wxspeechsynthesizerdelegate_2dp',['WXSpeechSynthesizerDelegate-p',['../protocol_w_x_speech_synthesizer_delegate-p.html',1,'']]],
  ['wxvoicedelegate_2dp',['WXVoiceDelegate-p',['../protocol_w_x_voice_delegate-p.html',1,'']]],
  ['wxvoiceresult',['WXVoiceResult',['../interface_w_x_voice_result.html',1,'']]],
  ['wxvoicesdk',['WXVoiceSDK',['../interface_w_x_voice_s_d_k.html',1,'']]],
  ['wxvoicewithuidelegate_2dp',['WXVoiceWithUIDelegate-p',['../protocol_w_x_voice_with_u_i_delegate-p.html',1,'']]]
];
