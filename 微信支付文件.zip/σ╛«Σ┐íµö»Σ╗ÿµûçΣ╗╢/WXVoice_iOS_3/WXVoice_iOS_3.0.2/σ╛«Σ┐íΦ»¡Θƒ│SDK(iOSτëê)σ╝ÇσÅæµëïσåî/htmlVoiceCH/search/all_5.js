var searchData=
[
  ['releasespeechsynthesizer',['releaseSpeechSynthesizer',['../interface_w_x_speech_synthesizer.html#a9c9c621153bd7311061a7f014f3c8354',1,'WXSpeechSynthesizer']]],
  ['releasewxvoice',['releaseWXVoice',['../interface_w_x_voice_s_d_k.html#ade674c522ef80bccb11fe127b8190a7a',1,'WXVoiceSDK']]]
];
