var searchData=
[
  ['initwithdelegate_3aandappid_3a',['initWithDelegate:andAppID:',['../interface_w_x_speech_recognizer_with_u_i.html#a185e4c92d12dcd04733723e1db686c5a',1,'WXSpeechRecognizerWithUI']]]
];
