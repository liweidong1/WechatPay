var searchData=
[
  ['voiceinputdidcancel',['voiceInputDidCancel',['../protocol_w_x_voice_with_u_i_delegate-p.html#adf29cf870ab8731fa5927523d68fec34',1,'WXVoiceWithUIDelegate-p::voiceInputDidCancel()'],['../protocol_w_x_voice_delegate-p.html#abc957c244a0eb1b5de9580329370c649',1,'WXVoiceDelegate-p::voiceInputDidCancel()']]],
  ['voiceinputmakeerror_3a',['voiceInputMakeError:',['../protocol_w_x_voice_with_u_i_delegate-p.html#a52f6db3558ffa3750b09625b90530e1a',1,'WXVoiceWithUIDelegate-p::voiceInputMakeError:()'],['../protocol_w_x_voice_delegate-p.html#a601a80ab69cd4a6376f17c9d404c2942',1,'WXVoiceDelegate-p::voiceInputMakeError:()']]],
  ['voiceinputresultarray_3a',['voiceInputResultArray:',['../protocol_w_x_voice_with_u_i_delegate-p.html#aa76655cc329deeb74f4ee1713ba68831',1,'WXVoiceWithUIDelegate-p::voiceInputResultArray:()'],['../protocol_w_x_voice_delegate-p.html#a1a732a4e3483a39b30f27460a60039a7',1,'WXVoiceDelegate-p::voiceInputResultArray:()']]],
  ['voiceinputvolumn_3a',['voiceInputVolumn:',['../protocol_w_x_voice_with_u_i_delegate-p.html#a32dc2b89c9184e53e4334b2316e01563',1,'WXVoiceWithUIDelegate-p::voiceInputVolumn:()'],['../protocol_w_x_voice_delegate-p.html#a7a070ab9d00107e46cae0e19ac26a5ce',1,'WXVoiceDelegate-p::voiceInputVolumn:()']]],
  ['voiceinputwaitforresult',['voiceInputWaitForResult',['../protocol_w_x_voice_with_u_i_delegate-p.html#a7d888d0d20b304e06c3ae88c8e36d5d0',1,'WXVoiceWithUIDelegate-p::voiceInputWaitForResult()'],['../protocol_w_x_voice_delegate-p.html#aa558d1886b1bffe6e2ab10ea2ef7f27c',1,'WXVoiceDelegate-p::voiceInputWaitForResult()']]]
];
