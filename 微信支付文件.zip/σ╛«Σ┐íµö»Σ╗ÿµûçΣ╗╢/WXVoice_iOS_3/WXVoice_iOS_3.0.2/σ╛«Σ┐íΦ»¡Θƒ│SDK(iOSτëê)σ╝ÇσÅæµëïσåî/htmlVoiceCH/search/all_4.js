var searchData=
[
  ['orientationchanged',['orientationChanged',['../interface_w_x_speech_recognizer_with_u_i.html#ae0c52f4c21edab3c551448b859788b9f',1,'WXSpeechRecognizerWithUI']]]
];
