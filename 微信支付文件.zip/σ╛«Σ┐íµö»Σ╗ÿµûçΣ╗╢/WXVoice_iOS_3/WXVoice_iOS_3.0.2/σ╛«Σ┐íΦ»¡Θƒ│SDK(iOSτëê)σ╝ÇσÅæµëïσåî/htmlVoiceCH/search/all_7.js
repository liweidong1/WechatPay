var searchData=
[
  ['text',['text',['../interface_w_x_voice_result.html#a2c24335672dda4e0a4630be797ebefa6',1,'WXVoiceResult']]]
];
