var protocol_w_x_voice_delegate_p =
[
    [ "voiceInputDidCancel", "protocol_w_x_voice_delegate-p.html#abc957c244a0eb1b5de9580329370c649", null ],
    [ "voiceInputMakeError:", "protocol_w_x_voice_delegate-p.html#a601a80ab69cd4a6376f17c9d404c2942", null ],
    [ "voiceInputResultArray:", "protocol_w_x_voice_delegate-p.html#a1a732a4e3483a39b30f27460a60039a7", null ],
    [ "voiceInputVolumn:", "protocol_w_x_voice_delegate-p.html#a7a070ab9d00107e46cae0e19ac26a5ce", null ],
    [ "voiceInputWaitForResult", "protocol_w_x_voice_delegate-p.html#aa558d1886b1bffe6e2ab10ea2ef7f27c", null ]
];