var interface_w_x_voice_s_d_k =
[
    [ "cancel", "interface_w_x_voice_s_d_k.html#a82695ca22dfac022d7d4ba683774e8ec", null ],
    [ "finish", "interface_w_x_voice_s_d_k.html#a3d3fe0f73e78fdeb8ee16edc8c636296", null ],
    [ "releaseWXVoice", "interface_w_x_voice_s_d_k.html#ade674c522ef80bccb11fe127b8190a7a", null ],
    [ "setAppID:", "interface_w_x_voice_s_d_k.html#acf136615739869f57f6ed0299aed79c7", null ],
    [ "setResultType:", "interface_w_x_voice_s_d_k.html#a64da26b4bf1a141ed557ec34fdfed697", null ],
    [ "sharedWXVoice", "interface_w_x_voice_s_d_k.html#a74994bbd2bc812635092d5767f834b76", null ],
    [ "startOnce", "interface_w_x_voice_s_d_k.html#ad8e8ced7d9a14c631a50df0147feb749", null ],
    [ "startOnceWithGrammarString:andType:", "interface_w_x_voice_s_d_k.html#a3d74367a6e3960ce28dfbe3bcd657c0d", null ],
    [ "delegate", "interface_w_x_voice_s_d_k.html#ac2976de99de360db40487412e179b492", null ],
    [ "domain", "interface_w_x_voice_s_d_k.html#ab7ad7ea678b7015b5c589fe0e0fc7f9e", null ],
    [ "silTime", "interface_w_x_voice_s_d_k.html#a92aeee2fe589fda4ee8b657955944cd3", null ]
];