var protocol_w_x_voice_with_u_i_delegate_p =
[
    [ "voiceInputDidCancel", "protocol_w_x_voice_with_u_i_delegate-p.html#adf29cf870ab8731fa5927523d68fec34", null ],
    [ "voiceInputMakeError:", "protocol_w_x_voice_with_u_i_delegate-p.html#a52f6db3558ffa3750b09625b90530e1a", null ],
    [ "voiceInputResultArray:", "protocol_w_x_voice_with_u_i_delegate-p.html#aa76655cc329deeb74f4ee1713ba68831", null ],
    [ "voiceInputVolumn:", "protocol_w_x_voice_with_u_i_delegate-p.html#a32dc2b89c9184e53e4334b2316e01563", null ],
    [ "voiceInputWaitForResult", "protocol_w_x_voice_with_u_i_delegate-p.html#a7d888d0d20b304e06c3ae88c8e36d5d0", null ]
];