var protocol_w_x_speech_synthesizer_delegate_p =
[
    [ "speechSynthesizerDidCancel", "protocol_w_x_speech_synthesizer_delegate-p.html#a3e21f31f8b070334fcaf388d5b612385", null ],
    [ "speechSynthesizerMakeError:", "protocol_w_x_speech_synthesizer_delegate-p.html#a7074376eea8dae6a895d3ea16967d0c8", null ],
    [ "speechSynthesizerResultSpeechData:speechFormat:", "protocol_w_x_speech_synthesizer_delegate-p.html#a356d4457510ff099f7738f717430230d", null ]
];