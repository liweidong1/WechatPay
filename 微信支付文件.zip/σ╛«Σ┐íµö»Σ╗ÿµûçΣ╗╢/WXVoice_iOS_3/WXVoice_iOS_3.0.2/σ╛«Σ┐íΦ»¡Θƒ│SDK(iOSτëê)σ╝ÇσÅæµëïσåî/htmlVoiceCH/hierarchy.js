var hierarchy =
[
    [ "<NSObject>", null, [
      [ "WXSpeechRecognizerWithUI", "interface_w_x_speech_recognizer_with_u_i.html", null ],
      [ "WXSpeechSynthesizer", "interface_w_x_speech_synthesizer.html", null ],
      [ "<WXSpeechSynthesizerDelegate>", "protocol_w_x_speech_synthesizer_delegate-p.html", null ],
      [ "WXVoiceResult", "interface_w_x_voice_result.html", null ],
      [ "WXVoiceSDK", "interface_w_x_voice_s_d_k.html", null ],
      [ "<WXVoiceWithUIDelegate>", "protocol_w_x_voice_with_u_i_delegate-p.html", null ]
    ] ],
    [ "<NSObjectNSObject>", null, [
      [ "<WXVoiceDelegate>", "protocol_w_x_voice_delegate-p.html", null ]
    ] ]
];