var annotated =
[
    [ "WXSpeechRecognizerWithUI", "interface_w_x_speech_recognizer_with_u_i.html", "interface_w_x_speech_recognizer_with_u_i" ],
    [ "WXSpeechSynthesizer", "interface_w_x_speech_synthesizer.html", "interface_w_x_speech_synthesizer" ],
    [ "<WXSpeechSynthesizerDelegate>", "protocol_w_x_speech_synthesizer_delegate-p.html", "protocol_w_x_speech_synthesizer_delegate-p" ],
    [ "<WXVoiceDelegate>", "protocol_w_x_voice_delegate-p.html", "protocol_w_x_voice_delegate-p" ],
    [ "WXVoiceResult", "interface_w_x_voice_result.html", "interface_w_x_voice_result" ],
    [ "WXVoiceSDK", "interface_w_x_voice_s_d_k.html", "interface_w_x_voice_s_d_k" ],
    [ "<WXVoiceWithUIDelegate>", "protocol_w_x_voice_with_u_i_delegate-p.html", "protocol_w_x_voice_with_u_i_delegate-p" ]
];