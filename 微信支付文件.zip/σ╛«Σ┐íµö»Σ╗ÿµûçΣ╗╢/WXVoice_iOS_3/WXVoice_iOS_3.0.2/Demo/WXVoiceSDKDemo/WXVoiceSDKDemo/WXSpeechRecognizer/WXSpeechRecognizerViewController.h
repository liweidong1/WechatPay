//
//  WXSpeechRecognizerViewController.h
//  WXVoiceSDKDemo
//
//  Created by 宫亚东 on 13-12-26.
//  Copyright (c) 2013年 Tencent Research. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "WXSpeechRecognizerView.h"

@interface WXSpeechRecognizerViewController : UIViewController
{
@public
    WXSpeechRecognizerView *_speechRecognizerView;
}
@end
