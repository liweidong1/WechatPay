//
//  WXGrammarWordlistView.h
//  WXVoiceSDKDemo
//
//  Created by 宫亚东 on 14-1-23.
//  Copyright (c) 2014年 Tencent Research. All rights reserved.
//

#import "WXSpeechRecognizerView.h"

@interface WXGrammarWordlistView : UIView


- (NSString *)text;

@end
