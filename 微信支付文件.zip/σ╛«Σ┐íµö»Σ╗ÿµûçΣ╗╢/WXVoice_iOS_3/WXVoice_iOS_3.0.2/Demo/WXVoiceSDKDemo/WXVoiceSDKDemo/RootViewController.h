//
//  RootViewController.h
//  WXVoiceSDKDemo
//
//  Created by 宫亚东 on 13-12-24.
//  Copyright (c) 2013年 Tencent Research. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface RootViewController : UIViewController

@end
