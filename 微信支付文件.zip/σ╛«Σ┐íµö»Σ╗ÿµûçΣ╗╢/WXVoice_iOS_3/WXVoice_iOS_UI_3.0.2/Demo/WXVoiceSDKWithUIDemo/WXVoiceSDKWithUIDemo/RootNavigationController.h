//
//  RootNavigationController.h
//  WXVoiceSDKWithUIDemo
//
//  Created by 宫亚东 on 14-3-31.
//  Copyright (c) 2014年 Tencent Research. All rights reserved.
//

#import <UIKit/UIKit.h>
@interface RootNavigationController : UINavigationController
@end
