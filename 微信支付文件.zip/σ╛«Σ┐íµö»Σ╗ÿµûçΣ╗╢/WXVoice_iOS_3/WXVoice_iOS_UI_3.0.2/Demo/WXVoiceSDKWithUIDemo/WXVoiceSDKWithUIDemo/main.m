//
//  main.m
//  WXVoiceSDKWithUIDemo
//
//  Created by 宫亚东 on 14-3-18.
//  Copyright (c) 2014年 Tencent Research. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "AppDelegate.h"

int main(int argc, char *argv[])
{
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
